from django.shortcuts import render,HttpResponse
import requests

# Create your views here.

api_key="55f686712d78b67032bd62e460adf0e3"
from django.shortcuts import render
import requests

api_key = "55f686712d78b67032bd62e460adf0e3"

def home(request):
    data = None 

    if request.method == 'POST':
        city_name = request.POST.get('q', '').strip()
        if city_name:
            resp_data = requests.get(f'https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}')
            data = resp_data.json()

    return render(request, 'home.html', {'data': data})
