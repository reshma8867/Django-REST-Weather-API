import requests

weather_api="https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}"
api_key="55f686712d78b67032bd62e460adf0e3"

# read (get)

city_name='ramanagara'
resp_data=requests.get(f'https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}')
print(resp_data)  # <Response [200]>


python_data=resp_data.json()
# print(type(python_data)) #<class 'dict'>

print(python_data)
 #{'coord': {'lon': 77.2805, 'lat': 12.7253}, 'weather': [{'id': 804, 'main': 'Clouds', 'description': 'overcast clouds', 'icon': '04d'}], 'base': 'stations', 'main': {'temp': 302.08, 'feels_like': 304.22, 'temp_min': 302.08, 'temp_max': 302.08, 'pressure': 1010, 'humidity': 61, 'sea_level': 1010, 'grnd_level': 928}, 'visibility': 10000, 'wind': {'speed': 2.43, 'deg': 358, 'gust': 3.27}, 'clouds': {'all': 99}, 'dt': 1760336901, 'sys': {'country': 'IN', 'sunrise': 1760316036, 'sunset': 1760358802}, 'timezone': 19800, 'id': 1258744, 'name': 'Ramanagara', 'cod': 200}

print(python_data['weather'][0]['description']) #overcast clouds