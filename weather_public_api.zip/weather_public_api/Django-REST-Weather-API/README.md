# Django-REST-Weather-API
A robust weather forecasting API built using Django and Django REST Framework. It fetches and serves real-time weather data from an external provider (e.g., OpenWeatherMap).
